import csv
from datetime import datetime, timedelta

def process_date(date_str):
    if "Вчера" in date_str:
        return "11 мая"
    elif all(char.isdigit() or char == ':' for char in date_str):
        return "12 мая"

    else:
        return date_str.split(",")[0]

csv_filename = "news.csv"
data = {}

with open(csv_filename, mode='r', newline='', encoding='utf-8') as file:
    reader = csv.reader(file)
    next(reader)
    for row in reader:

        views = int(row[0])
        date = process_date(row[1])
        if date in data:
            data[date].append(views)
        else:
            data[date] = []

print(data)
