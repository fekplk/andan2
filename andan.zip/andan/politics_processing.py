import csv
from datetime import datetime

def process_csv(file_name):
    data = {}
    with open(file_name, mode='r', newline='', encoding='utf-8') as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            if len(row) >= 2:
                views = int(row[0])
                date = row[1].split(",")[0]
                if date in data:
                    data[date].append(views)
                else:
                    data[date] = [views]
            else:
                print("Ошибка: некорректный формат строки:", row)
    return data

def calculate_average(data):
    average_data = {}
    for date, views_list in data.items():
        if views_list:
            average_data[date] = sum(views_list) / len(views_list)
        else:
            average_data[date] = 0
    return average_data

def write_to_csv(data, output_file):
    with open(output_file, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Date', 'Average Views'])
        for date, average_views in sorted(data.items(), key=lambda x: datetime.strptime(x[0], "%d %B %Y") if x[0] != '2 июня' else x[0]):
            writer.writerow([date, int(average_views)])

def main():
    economy_data = process_csv("economy_processed.csv")
    average_economy = calculate_average(economy_data)
    write_to_csv(average_economy, "average_economy.csv")
    news_data = process_csv("politics_processed.csv")
    average_news = calculate_average(news_data)
    write_to_csv(average_news, "average_news.csv")

if __name__ == "__main__":
    main()

