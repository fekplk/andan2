from bs4 import BeautifulSoup
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.webdriver.chrome.options import Options
import csv


o = Options()
o.add_experimental_option("detach", True)
link = "https://ria.ru/defense_safety/"
driver = webdriver.Chrome(options=o)
driver.get(link)
last_height = driver.execute_script("return document.body.scrollHeight")
filter_button = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, '//*[@id="content"]/div/div[1]/div/div[1]/div[3]'))
)
filter_button.click()
period_button = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, '//*[@id="body"]/div[20]/div[2]/ul/li[4]'))
)
period_button.click()
WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.CLASS_NAME, "list-item__views-text"))
)
time.sleep(8)
k = 0
while True:
    try:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        more_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '[class*=list-more]'))
        )
        more_button.click()
        time.sleep(4)
        k += 1
        print(k)
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "list-item__title"))
        )
    except Exception as e:
        break
html_content = driver.page_source
soup = BeautifulSoup(html_content, 'html.parser')
html_content = driver.page_source
soup = BeautifulSoup(html_content, "lxml")
news_items = soup.find_all(class_="list-item")
views_items = soup.find_all(class_="list-item__views-text")
date_items = soup.find_all(class_="list-item__date")
csv_filename = "politics.csv"
with open(csv_filename, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=["просмотры", "дата"])
    writer.writeheader()
    for i in range(len(views_items)):
        row = {"просмотры": views_items[i].text, "дата": date_items[i].text}
        writer.writerow(row)
